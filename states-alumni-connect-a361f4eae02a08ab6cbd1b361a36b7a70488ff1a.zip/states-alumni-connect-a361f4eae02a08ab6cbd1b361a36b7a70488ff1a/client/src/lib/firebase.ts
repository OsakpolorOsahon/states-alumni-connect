// Firebase removed - using Supabase instead
// This file is kept for backwards compatibility but exports nothing
export const auth = null;
export const db = null;
export const storage = null;
export default null;